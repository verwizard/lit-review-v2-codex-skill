# 2023—2026 年音频识别与音频分类：结构化目标证据综述

## 摘要

本文围绕 2023—2026 年音频识别与音频分类研究开展结构化目标证据综述，重点覆盖通用音频表征、自监督预训练、音频—语言开放词表识别、提示与类别语义、声学场景分类（ASC）、低复杂度与硬件部署，以及少样本/增量学习。检索采用 targeted 模式：以上一轮已核验项目作为种子，并刷新 PMLR、ICASSP、Interspeech/ISCA、IJCAI、DCASE 正式 proceedings、ACL Anthology、IEEE、Springer/Nature 等官方或机构页面。截至 2026-09-04，候选集共 46 条，经两阶段筛选纳入 32 篇、排除 14 篇；其中 14 篇为 strong 全文/主要结果核验，18 篇为 partial。由于没有执行数据库级穷尽检索和可复现的真实总命中数导出，本文应称为“结构化目标证据综述”，而非系统综述。2026 年仅覆盖至 9 月 4 日，不应用文献数量解释完整年度趋势。

综合证据显示，近年的变化不是单一模型替代，而是四类目标共同演进：可迁移表征、自然语言语义接口、域/设备鲁棒性以及资源约束。BEATs、M2D、EAT 与 AxLSTM 等研究表明基础表征已显著增强，但跨任务结果并不支持统一最优骨干 [1,7,8,17]。CLAP、Pengi、M2D-CLAP 与后续 ALP 把分类扩展到自然语言驱动的开放词表场景，同时也暴露出训练文本、预训练域、目标函数与提示构造的敏感性 [2,3,6,9,25]。在部署侧，DCASE 低复杂度路线、流式模型、FPGA 处理器、训练免适配以及轻量 CNN 共同说明，准确率只是目标之一，模型内存、MACs、延迟、功耗、标签预算和适配成本同样重要 [5,11,15,20,26,28–31]。

**关键词：** 音频分类；音频识别；声学场景分类；自监督学习；音频—语言模型；零样本分类；低复杂度部署

## 1. 综述范围与研究问题

本文把“音频识别/分类”界定为：环境声音分类、声学场景分类、音频事件/标签识别，以及明确报告音频分类下游结果的通用表征研究。纯自动语音识别、纯生成/字幕、只做标签体系或数据集而没有合格分类方法实验的论文不作为核心证据。对基础模型与多模态模型，只要其正式论文给出与音频分类直接相关的实验，即可进入候选集。

本综述主要回答四个问题：第一，2023—2026 年主要技术路线如何演化；第二，哪些跨研究结论在不同协议下仍较稳定；第三，主要冲突是否来自模型本身，还是来自数据、提示、监督、设备和计算预算等异质性；第四，哪些方向对开放词表、低资源、持续学习和真实部署最具有可迁移意义。

## 2. 方法与证据边界

### 2.1 候选集来源与停止规则

本项目采用 targeted search，而非数据库穷尽式检索。候选来源包括：上一轮 27 篇纳入论文及其排除记录作为种子；ICML/PMLR、NeurIPS、CVPR、ICASSP、Interspeech/ISCA、IJCAI、DCASE 正式 proceedings、ACL Anthology、IEEE、Springer/Nature 与机构正式出版页的定向检索；以及对 2026 年新论文与 DCASE 2026 出版状态的更新检查。检索日志不记录伪造的数据库总命中数，所有来源和查询家族见 `search_log.csv`。

停止规则为：完成预设技术路线和核心 venue/journal 的更新检索，并进行两轮补充检索；第二轮新增记录不再产生新的主要技术路线，新增结果要么落入已建立路线，要么因预印本、challenge 页面、文献类型或年份不符合而排除。因此，46 条是可审计的目标候选集规模，而不是“全领域总文献数”。

### 2.2 两阶段筛选与证据核验

第一阶段依据标题/摘要进行直接相关性筛选；第二阶段核验文献类型、方法、实验结果、重复/版本关系以及可获得的证据。最终纳入 32 篇。`evidence_strength=strong` 仅表示主要方法、实验条件和关键结果已通过全文或充分正式文本核验；`partial` 表示当前仅能核验部分证据，并在 `evidence_checked` 中显式记录 `verified` 与 `not_verified`。它不是论文质量评分。

v2 另外独立记录 `methodological_quality` 和 `quality_flags`，关注额外预训练数据、训练/测试重叠、基线公平性、模型规模、随机性/方差、外部验证和未报告的 prompt/预处理等风险。跨论文数值比较还经过 `comparison_validity` 门控；若数据集、split、适配协议或额外监督不同，则不将数值写成直接排名。

## 3. 纳入证据概况与覆盖偏差

纳入研究按发表年份分布为：2023 年 6 篇、2024 年 11 篇、2025 年 10 篇、2026 年 5 篇。2026 年为不完整年度。DCASE 正式 proceedings 在纳入集中的占比较高，这与“低复杂度/设备鲁棒 ASC”作为重点方向直接相关，但也意味着本文对 ASC 的覆盖强于某些音频子领域。`coverage_audit.csv` 对年份、venue、路线、核验等级与方法学质量集中度进行了显式记录。

从证据核验看，strong 与 partial 并存。基础 SSL、部分 DCASE/ASC 以及开放获取的期刊论文具有较充分全文核验；一些 2025–2026 会议论文只能从正式 abstract、机构页面或有限全文中确认方法和结果方向，因此其精确效应量不被用于强跨论文排名。

## 4. 技术路线综合

### 4.1 基础音频表征：从离散 token 到效率与非 Transformer 骨干

BEATs 以语义化离散声学 token 替代单纯重构目标，正式全文在 AudioSet 与 ESC-50 上展示了很强的迁移能力 [1]。M2D 随后通过双网络 masked modeling 扩展通用表征，但它自己的跨任务表格已经给出关键反证：M2D 在部分任务领先，却在 ESC-50 线性评估落后于 ATST、在 AudioSet 微调上落后于 BEATs [7]。这意味着“general-purpose”更合理的解释是“跨多个任务保持竞争力”，而不是“所有任务统一第一”。

EAT 把基础模型的目标从精度扩展到预训练效率，在维持有竞争力的分类迁移同时报告明显更低的训练时间 [8]；AxLSTM 则显示音频 SSL 不必严格依赖 Transformer，其官方结果报告更低参数量和较强跨任务表现 [17]。因此，基础表征路线的稳定结论是：目标函数、掩蔽策略、监督注入和骨干架构共同形成性能—计算 Pareto 前沿 [1,7,8,17]，而不是出现唯一最优架构。

### 4.2 音频—语言模型：从固定标签集走向开放词表

CLAP 通过音频—文本对比学习，使类别名称或自然语言提示直接成为分类接口；其全文还明确显示，同一个 ESC-50 模型仅改变 prompt 就会出现数个百分点的差异 [2]。Pengi 将多种音频任务统一为文本生成，在一些闭集分类数据上取得更高结果，但在另一些数据集并不占优 [3]。ImageBind 则把音频纳入更广泛的跨模态嵌入空间，说明语义迁移并不只存在“音频—文本”一种实现方式 [4]。

后续工作把训练规模和目标函数继续扩大。4.6M 音频—文本对的通用自然语言监督工作覆盖 26 个下游任务 [6]；M2D-CLAP 把 acoustic SSL 与语言对齐结合，却在 ESC-50 上显露明显的预训练域依赖 [9]。ACL 2026 的 ALP 进一步在 10.7M CaptionStew 上比较 contrastive 与 captioning 目标，结论不是“某个目标永久更好”，而是 contrastive 更具数据效率、captioning 在规模扩大时更有可扩展性 [25]。

这组证据也形成一个重要冲突：更大数据量并不自动带来更好分类。CLAP 的附加弱配对 AudioSet 数据会使部分下游任务下降 [2]，而 [6]、[25] 又支持更广泛、更大规模的训练在合适数据/目标条件下提高迁移。因此更稳妥的综合是：**数据量必须与 pair/caption 质量、领域覆盖、初始化和目标函数一起解释** [2,6,25]。

### 4.3 提示、类别语义与零样本几何：语言侧已成为模型的一部分

A Sound Description 的多数据集实验表明，prompt 格式本身就能造成约 5–8 个点的平均差异，并且不存在对不同模型都统一最优的模板 [13]。LLM 生成的听觉属性 [14] 与 ReCLAP 的描述性 caption/prompt [19] 从不同方向支持“丰富声学语义有用”，但二者的 exact effect size 在本轮属于 partial，应把重点放在方向一致性而不是数值竞赛。

训练类别的几何关系也会改变零样本结论。控制实验 [22] 表明，seen 类越接近 unseen 类且内部更具多样性，零样本准确率越高。换言之，class split 本身就是协议的一部分。2026 年 ICASSP 的 entropy-guided prompt weighting 又把语言侧适配推进到推理阶段：无需标签，通过预测熵自动调整 prompt 权重，在五个数据集上报告一致收益 [32]。由于 [32] 的完整结果表尚未独立重审，它更适合被视为“正式发表的新兴方向”，而不是已经确立的最佳方法。

### 4.4 声学场景分类：标签、设备、域变化与上下文联合建模

ASC 是近年最清楚体现“现实约束”的路线。深层语义 ASC 工作说明语义事件建模与 MixupNorm 可以改善多设备分类 [10]；DCASE 2024 则把标签比例、128 kB 存储、30 MMAC 与未见设备统一纳入 benchmark [11]。在低标签条件下，预训练、集成平均与针对性增强可以继续回收明显准确率 [12]。

2025 年出现了两种不同的设备鲁棒思路：CochlScene 在可用 device ID 时采用 device-aware distillation/augmentation，并在严格预算下报告 60.5% macro accuracy [20]；entropy-guided curriculum 则更关注不增加推理成本的域泛化 [21]。二者并不真正冲突：前者依赖可靠设备元数据，后者更适合设备信息缺失或不稳定的部署。MobileASCNet [27] 使用 city/time context 进一步说明，现实 ASC 有时会主动利用上下文元数据。

2026 年结构感知 ASC [31] 又加入 HPSS、非对称卷积与双注意力，以信号处理先验改善效率和跨设备鲁棒性。当前可核验正式摘要支持其方向，但 exact latency/accuracy table 尚未完整核验，因此不能直接与 [10]、[20] 的数字排名。

### 4.5 低复杂度、流式、功耗与适配成本：效率不再只是“参数少”

CP-Mobile [5] 在严格存储/MAC 限制下展示了小型 CNN 学生网络与大型 teacher 的蒸馏路径；Streaming Audio Transformers [15] 将目标扩展到在线延迟和内存；EAT [8] 则把效率问题前移到预训练阶段。2023 年的硬件处理器工作 [28] 更进一步给出 FPGA 上 0.313 W 与 84.5% ESC-50 的实测结果，使“功耗”成为可观察指标，而不是参数量的代理。

2025–2026 年的轻量路线继续扩展系统成本的定义。Trainingless Adaptation [29] 报告无需梯度重训练的域适配收益，把“适配计算”纳入成本；SpectroMaskNet [30] 在四个数据集上验证小型双分支网络，并在 ESC-50 上以约 2.7M 参数接近大型 Transformer 的论文内对比结果；MSP [26] 只增加约 4.99k 参数便在两个 DCASE 基准上获得明显改善；结构感知框架 [31] 则同时面向参数、推理时间和跨设备鲁棒性。

这些结果不能组成一个简单排行榜：FPGA 功耗、参数量、MACs、预训练时长和在线延迟衡量的是不同系统层级。更合理的比较单位是**性能—存储—计算—延迟—功耗—适配成本的 Pareto 前沿** [5,8,15,26,28–31]。

### 4.6 少样本/增量学习与异质声音语义

FFCAC [18] 与 universal incremental bird classification [23] 都尝试把大部分表征冻结，只更新轻量分类器或适配层，从而以少量新样本扩充类别。现有纳入证据均为 partial，且后者集中在鸟声领域，因此这条路线应被描述为 promising/emerging，而不能写成“已经形成稳定最佳范式”。

另一条较小但重要的路线关注现实类别内部的高度异质性。Broad Sound Taxonomy 工作 [16] 表明，包含声学与语义信息的 pretrained embedding 比纯声学表示更有优势；后续层次/多模态研究 [24] 又发现，文本语义继续改善分类，而 hierarchy supervision 本身更多改善潜空间结构，未必提高 top-line accuracy。它提醒我们：“表征更有结构”和“分类准确率更高”不是同一结论。

## 5. 冲突与异质性综合

第一，**规模效应不是单变量规律**。[6]、[25] 支持更广泛/更大规模的音频—语言训练，但 [2] 的弱配对扩展出现任务退步。最可能的解释是 pair 质量、领域覆盖、目标函数与初始化差异，而不是论文互相否定。

第二，**基础模型没有统一排名**。[1]、[7]、[8] 都能在选定条件形成很强结果，但 [7] 自身已经出现任务间名次交换；[8] 还主动优化不同的计算点。因此本综述不支持只用一个 ESC-50 或 AudioSet 数字决定“最好模型”。

第三，**丰富语义通常有帮助，但没有统一 prompt**。[13]、[14]、[19]、[32] 总体支持语言侧优化，[13] 却明确说明不同模型对模板的最优点不同；[22] 又证明 class split 几何也会改变零样本结果。prompt、类别描述与 seen/unseen 构成都应被报告为评测协议的一部分。

第四，**设备感知与设备不变方法的边界在于元数据**。[20] 在 device ID 可用时能利用额外条件，而 [10]、[21]、[31] 更倾向在表征/训练过程中追求跨设备稳健性。部署时如果设备信息未知或漂移，依赖 device ID 的优势可能缩小。

第五，**Transformer 强势不等于部署端必须 Transformer**。基础模型中 Transformer 很强 [1,8]，但 CP-Mobile、xLSTM、MSP、SpectroMaskNet 与硬件协同 CNN 都表明，在不同资源目标下非 Transformer 方案仍然具有竞争力 [5,17,26,28,30]。

第六，**语义结构不等于准确率提升**。[16]、[24] 支持 semantic metadata，而 [24] 又提示 hierarchy-aware training 可能主要改变潜空间结构。不同研究的 endpoint 必须区分。

## 6. 证据置信与敏感性检查

删除所有 partial 后，三类结论仍稳定：其一，不存在跨任务统一最优 foundation 路线，strong [1,7,8] 足以支持；其二，零样本性能高度依赖 prompt 与类几何，strong [2,13,22] 足以支持；其三，低复杂度音频识别是多目标优化，strong [5,10,11,20,26,30] 足以支持。

相对而言，audio-language 大规模扩展规律需要 partial [6,25] 才能形成跨阶段对照，因此完整“规模规律”置信度为 moderate；少样本/增量学习 [18,23] 缺少 strong 证据，结论只能为 suggestive；异质声音层次语义 [16,24] 也仍需要独立数据集验证。2026 的自动 prompt weighting [32] 是单篇 partial，因此只能作为新趋势。

## 7. 覆盖边界与综述局限

本项目不是系统综述。候选集来自目标式多来源检索，因此不能声称覆盖了所有 2023—2026 论文，也不能用候选数量生成 PRISMA 式“数据库命中率”。DCASE 论文占比较高，使设备/低复杂度 ASC 获得较好覆盖，但可能低估其他较分散的声音识别子领域。此外，不同论文在预训练数据、extra supervision、zero-shot 定义、线性探测/微调、ensemble、prompt、标签预算和硬件假设上差异显著，许多数值只能做方向性综合。

方法学质量与核验强度也必须分开理解：一篇论文可以全文核验充分但实验外部有效性有限；也可以方法设计看起来合理但当前只能获得摘要级证据。本文没有把 `strong/partial` 当作正式 risk-of-bias 工具，而另行记录 quality flags。

## 8. 研究空白与后续方向

未来最需要的不是在单一 benchmark 上继续增加不可比较的小幅精度，而是提高协议可比性。基础模型应同时报告预训练 FLOPs/时间、数据来源、额外监督、参数规模、线性探测和统一微调；audio-language 零样本研究应报告 prompt、caption 构造、训练/测试重叠与 class geometry；ASC/ESC 部署研究应将未知设备、开放类别、能耗、在线延迟和实际硬件统一纳入评估；少样本/增量研究则需要从专项领域扩展到更广环境声音，并长期报告 forgetting、adaptation cost 与 class-order sensitivity。

另一个重要方向是把“语义接口适配”和“声学表征适配”分开研究。2026 年的 label-free prompt weighting [32] 表明，即使冻结 audio-language backbone，推理阶段的语义权重仍可优化；与此同时，Trainingless Adaptation [29] 在声学/中间表示侧减少梯度训练。二者提示未来可能出现“冻结基础模型 + 低成本双侧适配”的新范式，但现有证据尚不足以确认其普遍性。

## 9. 结论

2023—2026 年音频分类与识别的主线可以概括为：**表征更可复用，类别接口更语言化，评价更面向真实约束**。基础 SSL 提升了迁移能力但没有形成统一赢家 [1,7,8,17]；audio-language 模型扩展了开放词表能力，同时把 prompt、caption 质量和 class geometry 变成新的关键变量 [2,13,22,25,32]；ASC 与 ESC 部署路线则从单一 accuracy 转向标签效率、设备鲁棒性、内存、MACs、延迟、功耗和适配成本的联合优化 [5,11,20,26,28–31]。

因此，未来更有解释力的论文不应只回答“比基线高多少”，还应回答性能提升来自哪里、代价是什么、在哪个协议下成立，以及当数据域、prompt、设备或计算条件变化时结论是否仍然保持。

## 参考文献

[1] Sanyuan Chen; Yu Wu; Chengyi Wang; Shujie Liu; Daniel Tompkins; Zhuo Chen; Wanxiang Che; Xiangzhan Yu; Furu Wei. BEATs: Audio Pre-Training with Acoustic Tokenizers. ICML 2023, PMLR 202:5178–5193, 2023.

[2] Benjamin Elizalde; Soham Deshmukh; Mahmoud Al Ismail; Huaming Wang. CLAP: Learning Audio Concepts From Natural Language Supervision. ICASSP 2023, 2023. DOI: 10.1109/ICASSP49357.2023.10095889.

[3] Soham Deshmukh; Benjamin Elizalde; Rita Singh; Huaming Wang. Pengi: An Audio Language Model for Audio Tasks. NeurIPS 2023, 2023. DOI: 10.52202/075280-0795.

[4] Rohit Girdhar; Alaaeldin El-Nouby; Zhuang Liu; Mannat Singh; Kalyan Vasudev Alwala; Armand Joulin; Ishan Misra. ImageBind: One Embedding Space To Bind Them All. CVPR 2023, pp. 15180–15190, 2023. DOI: 10.1109/CVPR52729.2023.01457.

[5] Florian Schmid; Tobias Morocutti; Shahed Masoudian; Khaled Koutini; Gerhard Widmer. Distilling the Knowledge of Transformers and CNNs with CP-Mobile. DCASE 2023 Workshop, pp. 161–165, 2023.

[6] Benjamin Elizalde; Soham Deshmukh; Huaming Wang. Natural Language Supervision for General-Purpose Audio Representations. ICASSP 2024, pp. 336–340, 2024. DOI: 10.1109/ICASSP48485.2024.10448504.

[7] Daisuke Niizumi; Daiki Takeuchi; Yasunori Ohishi; Noboru Harada; Kunio Kashino. Masked Modeling Duo: Towards a Universal Audio Pre-training Framework. IEEE/ACM TASLP 32:2391–2406, 2024. DOI: 10.1109/TASLP.2024.3389636.

[8] Wenxi Chen; Yuzhe Liang; Ziyang Ma; Zhisheng Zheng; Xie Chen. EAT: Self-Supervised Pre-Training with Efficient Audio Transformer. IJCAI 2024, pp. 3807–3815, 2024. DOI: 10.24963/ijcai.2024/421.

[9] Daisuke Niizumi; Daiki Takeuchi; Yasunori Ohishi; Noboru Harada; Masahiro Yasuda; Shunsuke Tsubaki; Keisuke Imoto. M2D-CLAP: Masked Modeling Duo Meets CLAP for Learning General-purpose Audio-Language Representation. Interspeech 2024, pp. 57–61, 2024. DOI: 10.21437/Interspeech.2024-29.

[10] Yun-Fei Shao; Xin-Xin Ma; Yong Ma; Wei-Qiang Zhang. Deep semantic learning for acoustic scene classification. EURASIP Journal on Audio, Speech, and Music Processing 2024:1, 2024. DOI: 10.1186/s13636-023-00323-5.

[11] Florian Schmid; Paul Primus; Toni Heittola; Annamaria Mesaros; Irene Martín-Morató; Khaled Koutini; Gerhard Widmer. Data-Efficient Low-Complexity Acoustic Scene Classification in the DCASE 2024 Challenge. DCASE 2024 Workshop, 2024.

[12] David Nadrchal; Aida Rostamza; Patrick Schilcher. Data-Efficient Acoustic Scene Classification with Pre-Training, Bayesian Ensemble Averaging, and Extensive Augmentations. DCASE 2024 Workshop, 2024.

[13] Michel Olvera; Paraskevas Stamatiadis; Slim Essid. A Sound Description: Exploring Prompt Templates and Class Descriptions to Enhance Zero-Shot Audio Classification. DCASE 2024 Workshop, pp. 116–120, 2024.

[14] Xuenan Xu; Pingyue Zhang; Ming Yan; Ji Zhang; Mengyue Wu. Enhancing Zero-shot Audio Classification using Sound Attribute Knowledge from Large Language Models. Interspeech 2024, pp. 4808–4812, 2024. DOI: 10.21437/Interspeech.2024-1692.

[15] Heinrich Dinkel; Zhiyong Yan; Yongqing Wang; Junbo Zhang; Yujun Wang; Bin Wang. Streaming Audio Transformers for Online Audio Tagging. Interspeech 2024, pp. 1145–1149, 2024. DOI: 10.21437/Interspeech.2024-242.

[16] Panagiota Anastasopoulou; Jessica Torrey; Xavier Serra; Frederic Font. Heterogeneous Sound Classification with the Broad Sound Taxonomy and Dataset. DCASE 2024 Workshop, pp. 11–15, 2024.

[17] Sarthak Yadav; Sergios Theodoridis; Zheng-Hua Tan. AxLSTMs: learning self-supervised audio representations with xLSTMs. Interspeech 2025, pp. 3524–3528, 2025.

[18] Yongjie Si; Yanxiong Li; Jiaxin Tan; Qianhua He; Il-Youp Kwak. Fully Few-shot Class-incremental Audio Classification Using Multi-level Embedding Extractor and Ridge Regression Classifier. Interspeech 2025, pp. 1318–1322, 2025. DOI: 10.21437/Interspeech.2025-1085.

[19] Sreyan Ghosh; Sonal Kumar; Chandra Kiran Reddy Evuru; Oriol Nieto; Ramani Duraiswami; Dinesh Manocha. ReCLAP: Improving Zero Shot Audio Classification by Describing Sounds. ICASSP 2025, 2025. DOI: 10.1109/ICASSP49660.2025.10888123.

[20] Dominik Karasin; Ioan-Cristian Olariu; Michael Schöpf; Anna Szymańska. CochlScene Pre-Training and Device-Aware Distillation for Low-Complexity Acoustic Scene Classification. DCASE 2025 Workshop, pp. 210–214, 2025.

[21] Peihong Zhang; Yuxuan Liu; Zhixin Li; Rui Sang; Yiqiang Cai; Yizhou Tan; Shengchen Li. An Entropy-Guided Curriculum Learning Strategy for Data-Efficient Acoustic Scene Classification under Domain Shift. DCASE 2025 Workshop, pp. 100–104, 2025.

[22] Duygu Dogan; Huang Xie; Toni Heittola; Tuomas Virtanen. On the Role of Training Class Distribution in Zero-Shot Audio Classification. DCASE 2025 Workshop, pp. 205–209, 2025.

[23] Manjunath Mulimani; Annamaria Mesaros. Universal Incremental Learning for Few-Shot Bird Sound Classification. DCASE 2025 Workshop, pp. 90–94, 2025.

[24] Panagiota Anastasopoulou; Francesco Dal Rí; Xavier Serra; Frederic Font. Hierarchical and Multimodal Learning for Heterogeneous Sound Classification. DCASE 2025 Workshop, 2025.

[25] Wei-Cheng Tseng; Xuanru Zhou; Mingyue Huo; Yiwen Shao; Hao Zhang; Dong Yu. Revisiting Audio-language Pretraining for Learning General-purpose Audio Representation. ACL 2026, pp. 34244–34263, 2026. DOI: 10.18653/v1/2026.acl-long.1581.

[26] Pengxu Jiang; Xusheng Liu; Peng Li. Multi-scale pyramid pooling with low complexity for acoustic scene classification. Scientific Reports 16, Article 19818, 2026. DOI: 10.1038/s41598-026-50487-1.

[27] Haowen Li; Mou Wang; Zhengding Luo; Ee-Leng Tan; Ziyi Yang; Woon-Seng Gan. Semi-supervised Acoustic Scene Classification under Spatial-Temporal Variability with a CRNN-based Model. Audio-AAAI 2026, PMLR 312:38–47, 2026.

[28] Lujie Peng; Junyu Yang; Zhiyi Chen; Longke Yan; Xiben Jiao; Jianbiao Xiao; Liang Zhou; Liang Chang; Yu Long; Jun Zhou. A High Accuracy and Low Power CNN-Based Environmental Sound Classification Processor. IEEE Transactions on Circuits and Systems I 70(12):4865–4876, 2023. DOI: 10.1109/TCSI.2023.3299823.

[29] Noriyuki Tonami; Wataru Kohno; Keisuke Imoto; Yoshiyuki Yajima; Sakiko Mishima; Reishi Kondo; Tomoyuki Hino. Trainingless Adaptation of Pretrained Models for Environmental Sound Classification. ICASSP 2025, pp. 1–5, 2025. DOI: 10.1109/ICASSP49660.2025.10889784.

[30] Guorong Chen; Bao Zhang; Zhikang Ding; Ke Xiao; Pengyu Guan; Xianghan Xiao; Xiaoqiang Wang; Haixin Yi; Hong Hu; Weijie Zhang. A lightweight dual branch masking network for environmental sound classification. Scientific Reports 16, Article 3547 (online published 31 Dec 2025), 2025. DOI: 10.1038/s41598-025-33636-w.

[31] Weijie Liu; Yanyan Fan. Structure-aware acoustic scene classification: a feature decoupling framework using HPSS and asymmetric convolutions. Scientific Reports (2026), 2026. DOI: 10.1038/s41598-026-57502-5.

[32] Karim El Khoury; Maxime Zanella; Tiffanie Godelaine; Christophe De Vleeschouwer; Benoît Macq. Leveraging Prediction Entropy for Automatic Prompt Weighting in Zero-Shot Audio-Language Classification. ICASSP 2026, 2026. DOI: 10.1109/ICASSP55912.2026.11460685.
