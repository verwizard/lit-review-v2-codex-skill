# LitReview v2 执行报告：2023—2026 音频识别与音频分类

- 综述类型：structured evidence review（结构化目标证据综述）
- Search mode：targeted
- 检索/证据截止：2026-09-04
- 2026 年是否完整：否
- 候选集：46 条
- 最终纳入：32 篇
- 最终排除：14 篇
- strong：14 篇
- partial：18 篇

## 候选集来源

候选集由上一轮已核验项目种子 + 本轮官方 venue/publisher 定向更新组成。主要来源包括 PMLR、CVF、ICASSP/IEEE、ISCA/Interspeech、IJCAI、DCASE 正式 proceedings、ACL Anthology、Springer/Nature、机构正式发表页。`search_log.csv` 记录查询家族、日期和停止规则；targeted 检索不记录虚构数据库总命中数。

## 两阶段筛选

Pass A 判断主题与最低证据要求；Pass B 核验文献类型、方法、实验结果、重复/版本关系与证据可获得性。预印本-only、challenge technical report、综述、超出年份和实验无法有效核验的记录被排除。`screening.csv` 保留逐条理由。

## v2 新增质量控制

1. `evidence_locator`：强证据尽量定位到表格/章节；partial 记录到可核验页面/摘要。
2. `methodological_quality` 与 `quality_flags`：与 evidence_strength 分离。
3. `comparison_matrix.csv`：跨论文数字仅在协议足够可比时允许直接排名。
4. `claim_registry.csv`：先注册综合主张，再撰写 narrative。
5. `coverage_audit.csv`：审计年份、venue、技术路线、核验强度与方法学质量集中度。
6. partial sensitivity：主要结论在排除 partial 后重新检查。

## 主要覆盖偏差

DCASE 正式 proceedings 占比较高，这符合本综述的低复杂度/设备鲁棒 ASC 重点，但限制了对整个音频分类领域的代表性。2026 年截至 9 月 4 日，不能将其论文数量与完整年度直接比较。

## 交付文件

- metadata.json
- search_log.csv
- screening.csv
- evidence_table.csv
- reference_map.csv
- comparison_matrix.csv
- claim_registry.csv
- claim_confidence.csv
- conflict_matrix.csv
- evidence_matrix_by_route.csv
- coverage_audit.csv
- review_draft.md
- review_lint_report.json（由 lint 脚本生成）

本项目不声称为系统综述，不生成虚假的 PRISMA 流程或数据库命中数。
